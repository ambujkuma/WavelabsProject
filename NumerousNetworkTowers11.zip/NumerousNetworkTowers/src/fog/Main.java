package fog;

import java.util.Arrays;

public class Main {
	
	    public static void main(String[] args) {
	        NumerousNT numNt = new NumerousNT();
	        int[][] towers = {{1, 2, 5}, {2, 1, 7}, {3, 1, 9}};
	        int radius = 2;
	        int[] result = numNt.bestCoordinate(towers, radius);
	        System.out.println(Arrays.toString(result));
	    }

	}

